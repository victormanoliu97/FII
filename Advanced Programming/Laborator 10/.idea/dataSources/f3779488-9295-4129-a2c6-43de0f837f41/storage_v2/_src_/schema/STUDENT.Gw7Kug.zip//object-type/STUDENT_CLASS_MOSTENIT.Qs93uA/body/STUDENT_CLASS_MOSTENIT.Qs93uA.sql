CREATE TYPE BODY STUDENT_CLASS_MOSTENIT AS
  OVERRIDING MEMBER PROCEDURE AFISEAZA_STUDENT IS
    nume_student VARCHAR2(15);
    prenume_student VARCHAR2(30);
    BEGIN
    SELECT NUME INTO nume_student FROM STUDENTI WHERE ID = v_id_student;
    SELECT PRENUME INTO prenume_student FROM STUDENTI WHERE ID = v_id_student;
    DBMS_OUTPUT.PUT_LINE('STUDENTUL SUPRASCRIS ESTE ' || v_id_student || ' ' ||  nume_student || ' ' || prenume_student);
    END AFISEAZA_STUDENT;

END;
/

