CREATE TYPE BODY TELEFON_TYPE AS
        CONSTRUCTOR FUNCTION TELEFON_TYPE(v_nume_telefon VARCHAR2,
        v_tip_procesor VARCHAR2,
        v_memorie_ram NUMBER,
        v_capacitate_stocare NUMBER,
        v_camera_px NUMBER) RETURN SELF AS RESULT AS BEGIN
        SELF.v_nume_telefon := v_nume_telefon;
        SELF.v_tip_procesor := v_tip_procesor;
        SELF.v_memorie_ram := v_memorie_ram;
        SELF.v_capacitate_stocare := v_capacitate_stocare;
        SELF.v_camera_px := v_camera_px;
      RETURN;
    END;

    NOT FINAL /*FINAL*/ MEMBER PROCEDURE GET_NUME_TELEFON IS
      BEGIN
      DBMS_OUTPUT.PUT_LINE('NUMELE TELEFONULUI ESTE: ' || v_nume_telefon);
    END GET_NUME_TELEFON;

    MEMBER PROCEDURE CRESTE_CAPACITATE_STOCARE IS BEGIN
      v_capacitate_stocare := v_capacitate_stocare + 20;
    END CRESTE_CAPACITATE_STOCARE;

    MEMBER PROCEDURE CRESTE_CAPACITATE_STOCARE(v_capacitate_majorare NUMBER) IS BEGIN
      v_capacitate_stocare := v_capacitate_stocare + v_capacitate_majorare;
    END CRESTE_CAPACITATE_STOCARE;

    MEMBER PROCEDURE GET_CAPACITATE_STOCARE IS BEGIN
      DBMS_OUTPUT.PUT_LINE('CAPACITATEA DE STOCARE ESTE: ' || v_capacitate_stocare);
    END GET_CAPACITATE_STOCARE;

    MAP MEMBER FUNCTION RAM_PER_STOCARE RETURN NUMBER IS BEGIN
      RETURN v_memorie_ram / v_capacitate_stocare;
    END RAM_PER_STOCARE;

END;
/

