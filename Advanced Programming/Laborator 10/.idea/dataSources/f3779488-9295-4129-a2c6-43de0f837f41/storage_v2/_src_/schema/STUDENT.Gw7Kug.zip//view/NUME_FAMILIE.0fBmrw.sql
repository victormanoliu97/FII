CREATE VIEW NUME_FAMILIE AS
  select nume from studenti
/

