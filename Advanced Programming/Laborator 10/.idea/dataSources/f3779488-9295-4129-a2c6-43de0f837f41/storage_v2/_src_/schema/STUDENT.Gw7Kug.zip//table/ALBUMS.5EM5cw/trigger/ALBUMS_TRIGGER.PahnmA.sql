CREATE TRIGGER ALBUMS_TRIGGER
  BEFORE INSERT
  ON ALBUMS
  FOR EACH ROW
  begin
    select albums_sequence.nextval into :new.id from dual;
  END;
/

