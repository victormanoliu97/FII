CREATE PACKAGE BODY MANAGEMENT_ERASMUS IS

  PROCEDURE INTITIALIZEAZA_TABELA IS BEGIN
    EXECUTE IMMEDIATE 'CREATE TABLE STUDENTI_ERASMUS(ID_INREGISTRARE NUMBER(*), NR_MATRICOL_STUDENT VARCHAR2(6), NUME_STUDENT VARCHAR2(15), PRENUME_STUDENT VARCHAR2(30), TARA NUMBER(*))';
    EXECUTE IMMEDIATE 'CREATE UNIQUE INDEX nr_matricol_student_index ON STUDENTI_ERASMUS(NR_MATRICOL_STUDENT)';
    END;

  PROCEDURE POPULEAZA_TABELA IS BEGIN

    --MANAGEMENT_ERASMUS.INTITIALIZEAZA_TABELA();
    lista_studenti_id := LISTA_TYPE(NULL);
    id_maxim_erasmus := 0;
    v_contor_nrmat := 0;
    v_cod_tara := 0;
    --id_inregistrare_max := 1;


    FOR i in 1..99 LOOP
      lista_studenti_id.extend();
      v_id_generat_random := TRUNC(DBMS_RANDOM.VALUE(1,100));
      lista_studenti_id(i) := v_id_generat_random;
    END LOOP;


    --SELECT ID_INREGISTRARE INTO id_inregistrare_max FROM STUDENTI_ERASMUS WHERE ID_INREGISTRARE = (SELECT MAX(ID_INREGISTRARE) FROM STUDENTI_ERASMUS) and ROWNUM=1;

    FOR i in 1..100 LOOP

    BEGIN

    SELECT COUNT(ID_INREGISTRARE) INTO id_maxim_erasmus FROM STUDENTI_ERASMUS;

    IF id_maxim_erasmus > 100 THEN
      RAISE nr_maxim_studenti_exception;
    END IF;

    --SELECT ID_INREGISTRARE INTO id_inregistrare_max FROM STUDENTI_ERASMUS WHERE ID_INREGISTRARE = (SELECT MAX(ID_INREGISTRARE) FROM STUDENTI_ERASMUS) AND ROWNUM<=1;

    INSERT INTO STUDENTI_ERASMUS(ID_INREGISTRARE, NR_MATRICOL_STUDENT, NUME_STUDENT, PRENUME_STUDENT, TARA) VALUES (
      i,
      (SELECT NR_MATRICOL FROM STUDENTI WHERE ID = lista_studenti_id(i)),
      (SELECT NUME FROM STUDENTI WHERE ID = lista_studenti_id(i)),
      (SELECT PRENUME FROM STUDENTI WHERE ID = lista_studenti_id(i)),
      200
    );

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
          OPEN studenti_fail_cursor(lista_studenti_id(i));
            LOOP
            FETCH studenti_fail_cursor INTO linie_student_fail_id, linie_student_fail_mat, linie_student_fail_nume, linie_student_fail_prenume;
            EXIT WHEN studenti_fail_cursor%NOTFOUND;
            END LOOP;
          CLOSE studenti_fail_cursor;
          CONTINUE;

      WHEN nr_maxim_studenti_exception THEN RAISE_APPLICATION_ERROR(-20016, 'NUMARUL MAXIM DE STUDENTI PENTRU ACEASTA TABELA A FOST ATINS');

    END;

    INSERT INTO STUDENTI_ERASMUS_AUX VALUES (linie_student_fail_mat, linie_student_fail_nume, linie_student_fail_prenume);

    --DBMS_OUTPUT.PUT_LINE('STUDENTI CE NU AU PUTUT FI INSERATI DEOARECE EXISTA DEJA IN BAZA DE DATE: ');
    DBMS_OUTPUT.PUT_LINE('STUDENTUL' || ' ' || linie_student_fail_id || ' ' || linie_student_fail_mat || ' ' || linie_student_fail_nume || ' ' || linie_student_fail_prenume || ' EXISTA DEJA IN TABELA');

    OPEN studenti_suces_cursor;
      LOOP
        FETCH studenti_suces_cursor INTO linie_student_suces_mat, linie_student_suces_nume, linie_student_suces_prenume;
        EXIT WHEN studenti_suces_cursor%NOTFOUND;
      END LOOP;
    CLOSE studenti_suces_cursor;

    DBMS_OUTPUT.PUT_LINE(CHR(10));
    --DBMS_OUTPUT.PUT_LINE('STUDENTI INSERATI CU SUCCES');
    DBMS_OUTPUT.PUT_LINE('STUDENTUL' || ' ' || linie_student_suces_mat || ' ' || linie_student_suces_nume || ' ' || linie_student_suces_prenume || ' A FOST INSERAT CU SUCCES' );

    test_suces_mat := linie_student_suces_mat;

    END LOOP;

    END;

END MANAGEMENT_ERASMUS;
/

