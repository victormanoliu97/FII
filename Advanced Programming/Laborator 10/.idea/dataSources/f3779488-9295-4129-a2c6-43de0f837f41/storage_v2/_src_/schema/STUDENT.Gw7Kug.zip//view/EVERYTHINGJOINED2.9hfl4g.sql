CREATE VIEW EVERYTHINGJOINED2 AS
  select s.nume, s.prenume from studenti s
join note n on s.id = n.id_student
join cursuri c on n.id_curs = c.id
join didactic d on d.id_curs = c.id
join profesori p on d.id_profesor = p.id
/

