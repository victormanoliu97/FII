CREATE PACKAGE BODY facultate IS

  PROCEDURE varsta_student(v_id_student STUDENTI.ID%TYPE) IS BEGIN

      SELECT data_nastere INTO v_data_nastere_user FROM studenti WHERE  ID = v_id_student;
      v_data_nastere_in_format_data := TO_DATE(v_data_nastere_user, 'DD/MM/YYYY');

      v_numar_ani := TRUNC(MONTHS_BETWEEN(  TO_CHAR(TO_DATE(SYSDATE, 'DD-MM-YYYY')) , TO_CHAR(TO_DATE(v_data_nastere_user, 'DD-MM-YYYY')))/12);
      v_numar_luni := FLOOR( MONTHS_BETWEEN(SYSDATE, v_data_nastere_in_format_data) - 12* TRUNC(MONTHS_BETWEEN(SYSDATE, TO_DATE(v_data_nastere_user, 'DD-MM-YYYY'))/12) );
      v_numar_zile :=  TRUNC(SYSDATE-add_months(v_data_nastere_in_format_data,trunc(MONTHS_BETWEEN(SYSDATE,v_data_nastere_in_format_data)/12)*12+TRUNC(MOD(MONTHS_BETWEEN(SYSDATE,v_data_nastere_in_format_data),12))));

      --DBMS_OUTPUT.PUT_LINE('De la data de: ' || v_data_nastere_user || ' au trecut ' || v_numar_luni || ' luni' || ' si ' || v_numar_zile || ' zile');
      DBMS_OUTPUT.PUT_LINE('Studentul: ' || ' nascut la data de ' || v_data_nastere_user || ' are varsta de: ' || v_numar_ani || ' ani ' || v_numar_luni || ' luni' || ' si ' || v_numar_zile || ' zile');

  END varsta_student;

  PROCEDURE varsta_student_caller(v_id_student STUDENTI.ID%TYPE) IS BEGIN

    varsta_student(v_id_student);

  END varsta_student_caller;

  PROCEDURE informatii_student(v_id_student STUDENTI.ID%TYPE) IS BEGIN

      SELECT nr_matricol INTO v_nr_matricol FROM studenti WHERE ID = v_id_student;
      SELECT AVG(valoare) INTO v_medie FROM NOTE WHERE id_student = v_id_student;

      DBMS_OUTPUT.NEW_LINE;
      DBMS_OUTPUT.PUT_LINE('Numar matricol:' || ' ' || v_nr_matricol);
      varsta_student_caller(v_id_student);
      DBMS_OUTPUT.PUT_LINE('Media:' || ' ' || v_medie);

      OPEN foaie_matricola_student(v_id_student);
      LOOP
        FETCH foaie_matricola_student INTO v_nume_curs, v_nota_curs;
        EXIT WHEN foaie_matricola_student%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('Cursul:' || v_nume_curs || ' ' || ' nota: ' || v_nota_curs);
      END LOOP;
      CLOSE foaie_matricola_student;

      OPEN prieteni_student(v_id_student);
      LOOP
        FETCH prieteni_student INTO v_prieten_student_nume, v_prieten_student_prenume;
        EXIT WHEN prieteni_student%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('Prieteni: ' || v_prieten_student_nume || ' ' || v_prieten_student_prenume);
      END LOOP;
      CLOSE prieteni_student;

      OPEN sorteaza(v_id_student);
      LOOP
        FETCH sorteaza INTO v_sortare_id, v_sortare_nume;
        EXIT WHEN sorteaza%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(v_sortare_id || ' ' ||  v_sortare_nume);
      END LOOP;
      CLOSE sorteaza;


  END informatii_student;

PROCEDURE adauga_student(v_nume_student STUDENTI.nume%TYPE, v_prenume_student STUDENTI.prenume%TYPE) IS BEGIN

      select id into v_student_id_aux from studenti where rownum=1 order by id desc;
      v_student_id_aux := v_student_id_aux+1;

      v_random_aux := DBMS_RANDOM.VALUE(0,40);
      v_random_aux_mod := mod(v_random_aux, 7);

      v_an := 2;
      v_random_grupa := TRUNC(DBMS_RANDOM.VALUE(1,7));

      if(mod(v_random_aux_mod,2) = 0) then
          v_student_nr_matricol := mod(v_student_id_aux,10) || upper(substr(v_nume_student, 1,1)) || substr(v_nume_student, 2,1) || upper(substr(v_nume_student,3,1)) || upper(substr(v_prenume_student,1,1)) || upper(substr(v_prenume_student,2,1));
      else
          v_student_nr_matricol := mod(v_student_id_aux,10)  || upper(substr(v_nume_student, 1,1)) || upper(substr(v_nume_student, 2,1)) || upper(substr(v_prenume_student,1,1)) || upper(substr(v_prenume_student,2,1)) || upper(substr(v_prenume_student, 3,1));
      end if;

      if(mod(v_random_aux_mod,2) = 0) then
          v_bursa := TRUNC(DBMS_RANDOM.VALUE(580,700));
      else
          v_bursa := null;
      end if;

      if(mod(v_random_aux_mod,2)=0) then
           v_grupa := 'A' || to_char(v_random_grupa);
      else
            v_grupa := 'B' || to_char(v_random_grupa);
      end if;

      v_data_nastere := SYSDATE - TRUNC(DBMS_RANDOM.VALUE(0,7183));

      v_random_an_aux := mod(v_random_an,4);

      if(mod(v_random_an_aux,2)=0) then
          v_mail := lower(v_nume_student ||'.'||v_prenume_student) || '@info.ro';
      elsif (mod(v_random_an_aux,2) = 2) then
          v_mail := lower(v_nume_student ||'.'||v_prenume_student) || '@yahoo.com';
      else
          v_mail := lower(v_nume_student ||'.'||v_prenume_student)|| '@gmail.com';
      end if;

      INSERT INTO STUDENTI VALUES(v_student_id_aux, v_student_nr_matricol, v_nume_student, v_prenume_student, v_an, v_grupa, v_bursa, v_data_nastere, v_mail, SYSDATE, SYSDATE);

      SELECT ID INTO v_id_nota FROM NOTE WHERE ROWNUM=1 ORDER BY ID DESC;

      IF(v_an = 2) THEN
        FOR v_contor in 1..8 LOOP
          v_id_nota := v_id_nota + 1;
          v_nota_random := DBMS_RANDOM.VALUE(1,10);
          INSERT INTO NOTE VALUES( v_id_nota, v_student_id_aux, v_contor, v_nota_random, SYSDATE, SYSDATE, SYSDATE );
        END LOOP;
      ELSIF (v_an=3) THEN
        FOR v_contor in 1..16 LOOP
          v_id_nota := v_id_nota + 1;
          v_nota_random := DBMS_RANDOM.VALUE(1,10);
          INSERT INTO NOTE VALUES( v_id_nota, v_student_id_aux, v_contor, v_nota_random, SYSDATE, SYSDATE, SYSDATE );
        END LOOP;
      ELSE
        FOR v_contor in 1..24 LOOP
          v_id_nota := v_id_nota + 1;
          INSERT INTO NOTE VALUES(v_id_nota, v_student_id_aux, v_contor, 0, SYSDATE, SYSDATE, SYSDATE);
        END LOOP;
      END IF;


  END adauga_student;

    PROCEDURE sterge_student(v_id_student STUDENTI.ID%TYPE) IS BEGIN

        DELETE FROM PRIETENI WHERE ID_STUDENT1 = v_id_student OR ID_STUDENT2 = v_id_student;
        DELETE FROM NOTE WHERE ID_STUDENT = v_id_student;
        DELETE FROM STUDENTI WHERE ID = v_id_student;

    END sterge_student;

END facultate;
/

