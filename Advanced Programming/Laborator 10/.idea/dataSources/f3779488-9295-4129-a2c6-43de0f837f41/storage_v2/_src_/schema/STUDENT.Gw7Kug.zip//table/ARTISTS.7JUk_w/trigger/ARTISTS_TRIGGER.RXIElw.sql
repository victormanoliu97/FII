CREATE TRIGGER ARTISTS_TRIGGER
  BEFORE INSERT
  ON ARTISTS
  FOR EACH ROW
  begin
    select artists_sequence.nextval into :new.id from dual;
  END;
/

