CREATE PACKAGE facultate IS
  v_data_nastere_user DATE;
  v_data_nastere_in_format_data DATE;
  v_numar_ani NUMBER;
  v_numar_luni NUMBER;
  v_numar_zile NUMBER;

  v_nr_matricol STUDENTI.nr_matricol%TYPE;
  v_medie NUMBER;
  v_id_student STUDENTI.ID%TYPE;
  v_nume_curs CURSURI.titlu_curs%TYPE;
  v_nota_curs NOTE.valoare%TYPE;

  v_prieten_student_nume STUDENTI.NUME%TYPE;
  v_prieten_student_prenume STUDENTI.PRENUME%TYPE;

  v_student_id_aux STUDENTI.ID%TYPE;
  v_id STUDENTI.ID%TYPE;
  v_random_aux NUMBER;
  v_random_aux_mod NUMBER;
  v_random_an STUDENTI.AN%TYPE;
  v_random_grupa NUMBER;
  v_an STUDENTI.AN%TYPE;
  v_bursa STUDENTI.BURSA%TYPE;
  v_data_nastere STUDENTI.DATA_NASTERE%TYPE;
  v_mail STUDENTI.EMAIL%TYPE;
  v_grupa STUDENTI.GRUPA%TYPE;
  v_student_nr_matricol VARCHAR2(20);
  v_random_an_aux STUDENTI.AN%TYPE;

  --v_contor_cursuri INT := 0;
  v_id_nota NOTE.ID%TYPE;
  v_nota_random NOTE.VALOARE%TYPE;
  v_id_nota_aux NOTE.ID%TYPE;

  v_sortare_id STUDENTI.ID%TYPE;
  v_sortare_nume STUDENTI.NUME%TYPE;

  CURSOR foaie_matricola_student(tmp_id_student STUDENTI.ID%TYPE) IS
      SELECT cursuri.titlu_curs, note.valoare from cursuri
      JOIN note on note.id_curs = cursuri.id
      WHERE note.id_student = tmp_id_student;

    CURSOR prieteni_student(tmp_id_student STUDENTI.ID%TYPE) IS
      SELECT nume,prenume FROM studenti
      JOIN prieteni ON studenti.id = prieteni.id
      WHERE prieteni.id_student1 = tmp_id_student or prieteni.id_student2 = tmp_id_student;

  CURSOR sorteaza(tmp_id_student STUDENTI.ID%TYPE) IS
      SELECT id, nume from ( select  s.ID, s.NUME,  avg(n.VALOARE)
      from STUDENTI s
      join NOTE N ON s.ID = N.ID_STUDENT
      GROUP BY S.NUME, S.ID, S.GRUPA, S.AN
      ORDER BY AVG(N.VALOARE) DESC  );

  PROCEDURE varsta_student_caller(v_id_student STUDENTI.ID%TYPE);
  PROCEDURE adauga_student(v_nume_student STUDENTI.nume%TYPE, v_prenume_student STUDENTI.prenume%TYPE);
  PROCEDURE sterge_student(v_id_student STUDENTI.ID%TYPE);
  PROCEDURE informatii_student(v_id_student STUDENTI.ID%TYPE);
END facultate;
/

