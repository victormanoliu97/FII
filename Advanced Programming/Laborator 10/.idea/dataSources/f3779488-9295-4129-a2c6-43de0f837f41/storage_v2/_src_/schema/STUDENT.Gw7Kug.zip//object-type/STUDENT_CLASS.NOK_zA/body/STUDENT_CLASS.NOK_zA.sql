CREATE TYPE BODY STUDENT_CLASS AS
  CONSTRUCTOR FUNCTION STUDENT_CLASS(id_student NUMBER) RETURN SELF AS RESULT AS BEGIN
      SELF.id_student := id_student;
      RETURN;
  END;

  NOT FINAL MEMBER PROCEDURE AFISEAZA_STUDENT IS
    nume_student VARCHAR2(15);
    prenume_student VARCHAR2(30);
    BEGIN
    SELECT NUME INTO nume_student FROM STUDENTI WHERE ID = id_student;
    SELECT PRENUME INTO prenume_student FROM STUDENTI WHERE ID = id_student;
    DBMS_OUTPUT.PUT_LINE(id_student || ' ' ||  nume_student || ' ' || prenume_student);
    END AFISEAZA_STUDENT;

  MEMBER PROCEDURE MAJOREAZA_BURSA(v_suma_majorare STRING) IS BEGIN
    UPDATE STUDENTI SET BURSA = BURSA + TO_NUMBER(v_suma_majorare) WHERE ID = id_student;
  END MAJOREAZA_BURSA;

  MEMBER PROCEDURE MAJOREAZA_BURSA(v_suma_majorare NUMBER) IS BEGIN
    UPDATE STUDENTI SET BURSA = BURSA + v_suma_majorare;
    END MAJOREAZA_BURSA;

  MEMBER PROCEDURE CREEAZA_MAIL IS
    nume_student VARCHAR2(15);
    prenume_student VARCHAR2(30);
    BEGIN
    SELECT NUME INTO nume_student FROM STUDENTI WHERE ID = id_student;
    SELECT PRENUME INTO prenume_student FROM STUDENTI WHERE ID = id_student;
    DBMS_OUTPUT.PUT_LINE(lower(prenume_student) || '.' || lower(nume_student) || '@info.uaic.ro');
  END CREEAZA_MAIL;

  MAP MEMBER FUNCTION VARSTALUNI RETURN NUMBER IS
    v_data_nastere_user DATE;
    v_data_nastere_in_format_data DATE;
    BEGIN
      SELECT DATA_NASTERE INTO v_data_nastere_user FROM STUDENTI WHERE ID = id_student;
      v_data_nastere_in_format_data := TO_DATE(v_data_nastere_user, 'DD/MM/YYYY');
      RETURN FLOOR( MONTHS_BETWEEN(SYSDATE, v_data_nastere_in_format_data) - 12* TRUNC(MONTHS_BETWEEN(SYSDATE, TO_DATE(v_data_nastere_user, 'DD-MM-YYYY'))/12) );
    END VARSTALUNI;

  MEMBER FUNCTION GET_NAME RETURN VARCHAR2 IS
    nume_student VARCHAR2(15);
    BEGIN
    SELECT NUME INTO nume_student FROM STUDENTI WHERE ID = id_student;
    RETURN nume_student;
    END GET_NAME;

  MEMBER FUNCTION GET_PRENUME RETURN VARCHAR2 IS
    prenume_student VARCHAR2(30);
    BEGIN
    SELECT PRENUME INTO prenume_student FROM STUDENTI WHERE ID = id_student;
    RETURN prenume_student;
    END GET_PRENUME;

  END;
/

