CREATE PACKAGE BODY modificari IS

  PROCEDURE creste_bursa(var lista_modificari )
  IS BEGIN
  EXECUTE IMMEDIATE 'CREATE TABLE schimbare (id int, marire number(6,2))';
  --execute immediate 'create TYPE ListaBurse IS VARRAY(5) OF  number' ;
  --noileBurse := ListaBurse() ;
    FOR i IN var.FIRST..var.LAST
    LOOP

    select marire into verifica_bursa from schimbare where id=var(i).id;
    if(verifica_bursa is not null)then
       noileBurse.extend;
       nr:=noileBurse.count;
       noileBurse(nr):=verifica_bursa;
      UPDATE schimbare SET  marire=marire+(var(i).procent*marire)/100 where id=var(i).id;

    else UPDATE schimbare SET marire=100 where id=var(i).id;
         noileBurse.extend;
         nr:=noileBurse.count;
        -- noileBurse(nr):=marire;
    UPDATE schimbare SET  marire=marire+(var(i).procent*marire)/100 where id=var(i).id;

    FOR v_linie IN  (SELECT * FROM studenti) LOOP
     INSERT INTO schimbare(id,marire) values (v_linie.id,v_linie.bursa);
     END LOOP;

    end if;
    END LOOP;
  END creste_bursa;


END modificari;
/

