CREATE PACKAGE BODY management_facultate IS

 PROCEDURE varsta_student (p_id studenti.id%type)


 IS BEGIN
   SELECT data_nastere into  v_data_nastere from studenti where p_id=id;
    DBMS_OUTPUT.PUT_LINE('Studentul s-a nascut pe : ' ||v_data_nastere);
    SELECT MONTHS_BETWEEN(SYSDATE,v_data_nastere) into v_nrtotal_luni FROM dual;
   --  DBMS_OUTPUT.PUT_LINE('Nr total de luni este : ' ||v_nrtotal_luni);
     v_varsta_student:=floor(v_nrtotal_luni/12);
     v_ani_luni:=v_varsta_student*12;
    --SELECT MONTHS_BETWEEN(SYSDATE,v_data_nastere) into v_nrtotal_luni FROM dual;
     v_nr_luni:=v_nrtotal_luni-v_ani_luni;
    select ADD_MONTHS(v_data_nastere, v_nrtotal_luni) into v_noua_data from dual;
    select abs(SYSDATE-v_noua_data) into v_nr_zile from dual;
    DBMS_OUTPUT.PUT_LINE('Studentul are : ' ||v_varsta_student||' ani');
    DBMS_OUTPUT.PUT_LINE(v_nr_luni||' luni');
    DBMS_OUTPUT.PUT_LINE('si '||v_nr_zile||' zile');


   END varsta_student;


     PROCEDURE varsta_student_apeland (p_id studenti.id%type) IS BEGIN
     varsta_student(p_id);
   END varsta_student_apeland;



    PROCEDURE adauga_alt_student(p_nume studenti.nume%type, p_prenume studenti.prenume%type)
      IS BEGIN
      SELECT ID INTO ultim_id FROM STUDENTI WHERE ROWNUM=1 ORDER BY ID DESC;
      ultim_id := ultim_id+1;


      nrmatricol_optiune := length(p_nume)||length(p_prenume)||substr(p_nume,1,1)||substr(p_prenume,1,1)||ascii(substr(p_nume,1,1));
      p_an := CEIL(DBMS_RANDOM.VALUE(1,3));
      p_grupa:= 'A' || CHR(CEIL(DBMS_RANDOM.VALUE(1,7)));

      if(p_an>1) then
      p_bursa:=700;
      else p_bursa:=600;
      end if;

      p_data_nastere:=to_date('05-07-1997','DD-MM-YY');
      p_mail := p_nume||'.'||p_prenume||'@gmail.com';

      insert into studenti(id,nr_matricol,nume,prenume,an,grupa,bursa,data_nastere,email,created_at,UPDATED_AT)
         values(ultim_id,nrmatricol_optiune ,p_nume, p_prenume, p_an, p_grupa ,p_bursa, p_data_nastere ,p_mail ,sysdate,sysdate);
      /*
       insert into studenti(id,nr_matricol,nume,prenume,an,grupa,burssa,data_nastere,email,created_at,update_at)
         values(ultim_id,nrmatricol_optiune,p_nume,p_prenume,p_an,p_grupa,p_bursa,p_data_nastere,p_mail,sysdate,sysdate);
      */

      SELECT ID INTO ultim_nr_crt FROM note WHERE ROWNUM=1 ORDER BY ID DESC;

   curs_nr :=1;
   if(p_an=2) then

    while(curs_nr<=8)
    LOOP
     ultim_nr_crt:=ultim_nr_crt+1;
     valoare_nota:=ceil(dbms_random.value(4,10));
     curs_nr := curs_nr + 1;
     insert into note(id,id_student,id_curs,valoare,data_notare,created_at,UPDATED_AT)
          values( ultim_nr_crt , ultim_id, curs_nr, valoare_nota, sysdate,sysdate,sysdate);
   END LOOP;

   elsif (p_an=3) then
         while(curs_nr<=16)
    LOOP
     ultim_nr_crt:=ultim_nr_crt+1;
     valoare_nota:=ceil(dbms_random.value(4,10));
     insert into note(id,id_student,id_curs,valoare,data_notare,created_at,UPDATED_AT)
          values( ultim_nr_crt,ultim_id,curs_nr,valoare_nota,sysdate,sysdate,sysdate);
     curs_nr := curs_nr + 1;
   END LOOP;

   else  while(curs_nr<=24)
    LOOP
     ultim_nr_crt:=ultim_nr_crt+1;
     valoare_nota:=ceil(dbms_random.value(4,10));
     insert into note(id,id_student,id_curs,valoare,data_notare,created_at,UPDATED_AT)
          values( ultim_nr_crt,ultim_id,curs_nr,valoare_nota,sysdate,sysdate,sysdate);
     curs_nr := curs_nr + 1;
   END LOOP;


   end if;

    END adauga_alt_student;



  PROCEDURE stergere_alt_student (p_id studenti.id%type)
   IS BEGIN
   DELETE FROM PRIETENI WHERE PRIETENI.ID_STUDENT1 = p_id OR PRIETENI.ID_STUDENT2 = p_id;
   DELETE FROM NOTE WHERE NOTE.ID_STUDENT = p_id;
   DELETE FROM STUDENTI WHERE STUDENTI.ID = p_id;
   END stergere_alt_student;


  END management_facultate;
/

