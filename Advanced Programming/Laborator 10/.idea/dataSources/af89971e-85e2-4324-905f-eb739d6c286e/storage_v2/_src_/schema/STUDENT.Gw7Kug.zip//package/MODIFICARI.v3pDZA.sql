CREATE PACKAGE modificari  IS
  TYPE crestere IS RECORD (id int, procent number(5,3));
  TYPE lista_modificari IS VARRAY(100) OF crestere;
  PROCEDURE creste_bursa(var lista_modificari);

nr int;
verifica_bursa studenti.bursa%type;
TYPE ListaBurse IS VARRAY(5) OF  number;
noileBurse ListaBurse;

END modificari;
/

