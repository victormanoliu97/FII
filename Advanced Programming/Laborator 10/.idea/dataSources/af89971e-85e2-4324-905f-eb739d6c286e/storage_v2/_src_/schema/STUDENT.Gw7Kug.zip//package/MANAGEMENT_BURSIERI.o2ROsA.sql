CREATE PACKAGE management_bursieri IS

  TYPE MODIFICARI_BURSA IS RECORD (
    v_id_student STUDENTI.ID%TYPE,
    v_procentaj_modificare NUMBER
  );
  TYPE LISTA_STUDENTI IS VARRAY (1000) OF MODIFICARI_BURSA;

  CURSOR cursor_id_bursa(v_tmp STUDENTI.ID%TYPE) IS
    SELECT ID, BURSA FROM STUDENTI
    WHERE ID = v_tmp;
  TYPE CURSOR_ID_BURSA_TIP IS TABLE OF cursor_id_bursa%ROWTYPE;
  lista_studenti_id_bursa CURSOR_ID_BURSA_TIP;

  TYPE HISTORY_BURSE_TYPE IS VARRAY(1000) OF NUMBER;
  lista_history_burse HISTORY_BURSE_TYPE;
  bursa_initiala HISTORY_BURSE_TYPE;

  TYPE TABELA_HISTORY_TYPE IS VARRAY(1000) OF NUMBER;

  nr_modificari_burse NUMBER;
  p NUMBER;
  k NUMBER;
  aux_nr NUMBER;
  id_modificare_aux NUMBER;

  CURSOR cursor_history(v_tmp STUDENTI.ID%TYPE) IS
    SELECT HISTORY_BURSE FROM STUDENTI
    WHERE ID = v_tmp;
  linie_history_bursa_smechera STUDENTI.HISTORY_BURSE%TYPE;

  CURSOR aux_schimbari_history_cursor(v_tmp STUDENTI.ID%TYPE) IS
    SELECT SCHIMBARE FROM AUX_SCHIMBARI
    WHERE ID_STUDENT = v_tmp;
  myline_aux_schimbari STUDENTI.HISTORY_BURSE%TYPE;


  CURSOR modif_macar_o_data_cursor IS
    SELECT ID_STUDENT FROM AUX_SCHIMBARI;
  linie_studenti_modif_id STUDENTI.HISTORY_BURSE%TYPE;

  linie_modif_stud STUDENTi.HISTORY_BURSE%TYPE;


  PROCEDURE modifica_bursa(vector_lista_studenti IN OUT LISTA_STUDENTI);
  PROCEDURE modifica_baza_de_date;

END management_bursieri;
/

