-- Cannot generate trigger DELETE_TRIGGER: the table is unknown
/

