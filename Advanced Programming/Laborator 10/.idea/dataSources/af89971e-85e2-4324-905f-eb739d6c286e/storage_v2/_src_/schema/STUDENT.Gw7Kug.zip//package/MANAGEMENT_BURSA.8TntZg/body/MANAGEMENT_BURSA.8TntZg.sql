CREATE PACKAGE BODY MANAGEMENT_BURSA IS


  PROCEDURE UPDATE_TABLE_ON_EXCEPTION(v_id_student STUDENTI.ID%TYPE) IS BEGIN
    UPDATE STUDENTI SET BURSA = 3000 WHERE ID = v_id_student;
    END;

  PROCEDURE MAJOREAZA_BURSA(v_id_student STUDENTI.ID%TYPE, v_creste_bursa STUDENTI.BURSA%TYPE) IS BEGIN

    BEGIN

    OPEN bursa_initial_cursor(v_id_student);
    LOOP
      FETCH bursa_initial_cursor INTO v_student_initial_bursa;
      EXIT WHEN bursa_initial_cursor%NOTFOUND;
    END LOOP;
    CLOSE bursa_initial_cursor;

    IF v_student_initial_bursa IS NULL THEN
      UPDATE STUDENTI SET BURSA = 0 WHERE ID = v_id_student;
    ELSE
      UPDATE STUDENTI SET BURSA = BURSA + v_creste_bursa WHERE ID = v_id_student;
    END IF;

    OPEN bursa_curor(v_id_student);
    LOOP
      FETCH bursa_curor INTO v_student_bursa;
      EXIT WHEN bursa_curor%NOTFOUND;
    END LOOP;
    CLOSE bursa_curor;


    IF v_student_bursa >= 3000 THEN
      RAISE bursa_exception;
    END IF;

      EXCEPTION
      WHEN bursa_exception THEN
      UPDATE_TABLE_ON_EXCEPTION(v_id_student);
      DBMS_OUTPUT.PUT_LINE('La studentul cu id-ul ' || v_id_student || ' bursa a intrecut valoarea maxima de 3000 de lei ' ||  DBMS_UTILITY.FORMAT_ERROR_STACK || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE );

      END;

  END;

END MANAGEMENT_BURSA;
/

