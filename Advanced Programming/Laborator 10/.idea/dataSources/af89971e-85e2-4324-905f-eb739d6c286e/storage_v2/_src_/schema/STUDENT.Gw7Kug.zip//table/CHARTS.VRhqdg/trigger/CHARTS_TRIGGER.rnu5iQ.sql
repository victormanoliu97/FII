CREATE TRIGGER CHARTS_TRIGGER
  BEFORE INSERT
  ON CHARTS
  FOR EACH ROW
  begin
    select charts_sequence.nextval into :new.id FROM dual;
  END;
/

