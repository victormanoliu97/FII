CREATE PACKAGE management_facultate IS
v_data_nastere studenti.data_nastere%type;
v_nr_zile number(10);
v_nr_luni number(10);
v_nrtotal_luni number(10);
v_ani_luni number(10);
v_noua_data DATE;
v_varsta_student number(3);
ultim_id studenti.id%type;
p_an studenti.an%type;
p_grupa studenti.grupa%type;
p_bursa studenti.bursa%type;
p_data_nastere studenti.DATA_NASTERE%type;
nrmatricol_optiune STUDENTI.NR_MATRICOL%TYPE;
p_mail STUDENTI.EMAIL%TYPE;

ultim_nr_crt note.id%type;
valoare_nota note.valoare%type;
curs_nr NOTE.ID_CURS%TYPE;

PROCEDURE varsta_student_apeland (p_id studenti.id%type);
PROCEDURE adauga_alt_student(p_nume studenti.nume%type, p_prenume studenti.prenume%type);
PROCEDURE stergere_alt_student (p_id studenti.id%type);
END management_facultate;
/

