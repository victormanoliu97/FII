CREATE PACKAGE BODY management_bursieri IS

  PROCEDURE modifica_baza_de_date IS BEGIN
    EXECUTE IMMEDIATE 'CREATE TYPE TABELA_HISTORY_TYPE IS VARRAY(1000) OF NUMBER';
    EXECUTE IMMEDIATE 'ALTER TABLE STUDENTI ADD HISTORY_BURSE TABELA_HISTORY_TYPE';
  END;


  PROCEDURE modifica_bursa(vector_lista_studenti IN OUT LISTA_STUDENTI) IS BEGIN

    --EXECUTE IMMEDIATE 'CREATE TYPE TABELA_HISTORY_TYPE IS VARRAY(1000) OF NUMBER';
    --EXECUTE IMMEDIATE 'ALTER TABLE STUDENTI ADD HISTORY_BURSE TABELA_HISTORY_TYPE';
    --EXECUTE IMMEDIATE 'CREATE TABLE AUX_SCHIMBARI ( ID_MODIFICARE NUMBER(*), ID_STUDENT NUMBER(*), SCHIMBARE NUMBER(6,2))';
    lista_history_burse := HISTORY_BURSE_TYPE(NULL);
    bursa_initiala := HISTORY_BURSE_TYPE(NULL);

    p := 1;
    nr_modificari_burse := 0;
    FOR i in vector_lista_studenti.FIRST..vector_lista_studenti.LAST LOOP

      vector_lista_studenti.extend();

      OPEN cursor_id_bursa(vector_lista_studenti(i).v_id_student);
      SELECT ID, BURSA BULK COLLECT INTO lista_studenti_id_bursa FROM STUDENTI WHERE ID = vector_lista_studenti(i).v_id_student;
      CLOSE cursor_id_bursa;

      FOR k in 1..lista_studenti_id_bursa.COUNT LOOP

      lista_studenti_id_bursa.extend(vector_lista_studenti.COUNT);
      lista_history_burse.extend(lista_studenti_id_bursa.COUNT);
      bursa_initiala.extend(lista_studenti_id_bursa.COUNT);

      IF lista_studenti_id_bursa(k).ID = vector_lista_studenti(i).v_id_student THEN
        SELECT BURSA INTO bursa_initiala(1) FROM STUDENTI WHERE ID = vector_lista_studenti(i).v_id_student;
      END IF;

      IF lista_studenti_id_bursa(k).ID = vector_lista_studenti(i).v_id_student AND lista_studenti_id_bursa(k).BURSA IS NULL THEN
        UPDATE STUDENTI SET BURSA = 100 WHERE vector_lista_studenti(i).v_id_student = STUDENTI.ID AND STUDENTI.BURSA IS NULL;
        UPDATE STUDENTI SET BURSA = (vector_lista_studenti(i).v_procentaj_modificare/100) * BURSA + BURSA WHERE vector_lista_studenti(i).v_id_student = STUDENTI.ID AND BURSA IS NOT NULL;
      END IF;

      IF lista_studenti_id_bursa(k).ID = vector_lista_studenti(i).v_id_student AND lista_studenti_id_bursa(k).BURSA IS NOT NULL THEN
        UPDATE STUDENTI SET BURSA = (vector_lista_studenti(i).v_procentaj_modificare/100) * BURSA + BURSA WHERE vector_lista_studenti(i).v_id_student = STUDENTI.ID AND BURSA IS NOT NULL;
      END IF;

      OPEN cursor_history(vector_lista_studenti(i).v_id_student);
        LOOP
          nr_modificari_burse := nr_modificari_burse + 1;
          FETCH cursor_history INTO linie_history_bursa_smechera;
          EXIT WHEN cursor_history%NOTFOUND;
        END LOOP;
      CLOSE cursor_history;

      SELECT BURSA INTO lista_history_burse(nr_modificari_burse) FROM STUDENTI WHERE ID = vector_lista_studenti(i).v_id_student;

      SELECT COUNT(ID_MODIFICARE) INTO id_modificare_aux FROM AUX_SCHIMBARI;

      INSERT INTO AUX_SCHIMBARI VALUES ( id_modificare_aux+1, vector_lista_studenti(i).v_id_student, bursa_initiala(1) );
      INSERT INTO AUX_SCHIMBARI VALUES ( id_modificare_aux+1, vector_lista_studenti(i).v_id_student, lista_history_burse(nr_modificari_burse) );

      OPEN aux_schimbari_history_cursor(vector_lista_studenti(i).v_id_student);
        SELECT DISTINCT SCHIMBARE BULK COLLECT INTO myline_aux_schimbari FROM AUX_SCHIMBARI WHERE ID_STUDENT = vector_lista_studenti(i).v_id_student ORDER BY SCHIMBARE ASC;
      CLOSE aux_schimbari_history_cursor;

      UPDATE STUDENTI SET HISTORY_BURSE = myline_aux_schimbari WHERE ID = vector_lista_studenti(i).v_id_student;


      SELECT DISTINCT ID_STUDENT BULK COLLECT INTO linie_studenti_modif_id FROM AUX_SCHIMBARI;

      FOR x in linie_studenti_modif_id.FIRST..linie_studenti_modif_id.LAST LOOP
        OPEN aux_schimbari_history_cursor(linie_studenti_modif_id(x));
        CLOSE aux_schimbari_history_cursor;
        FOR y in myline_aux_schimbari.FIRST..myline_aux_schimbari.LAST LOOP
          DBMS_OUTPUT.PUT_LINE(linie_studenti_modif_id(x) || ' ' ||  myline_aux_schimbari(y));
        END LOOP;
      END LOOP;


      END LOOP;

    END LOOP;

  END;

END management_bursieri;
/

